# Dtest/__init__.py

__app_name__ = "Dtest"
__version__ = "0.1.0"